<div id="main-sidebar" class="main-sidebar">
    <div class="sidebar-wrapper">

        {{-- Logo --}}
        <a href="{{ route('agent.dashboard.index') }}" class="navbar-brand">
            <div class="logo-lg">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="40" class="mx-auto logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="40" class="mx-auto logo-light">
            </div>
            <div class="logo-sm">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="50" class="mx-auto logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="50" class="mx-auto logo-light">
            </div>
        </a>

        {{-- Agent Profile --}}
        <div class="dropdown profile-dropdown">
            <a href="#!" class="btn d-flex align-items-center w-100 gap-2 p-4 text-start" data-bs-toggle="dropdown" aria-expanded="false">
                @php $agent = Auth::user()->agent; @endphp
                @if($agent && $agent->profile_image)
                    <img src="{{ asset('storage/' . $agent->profile_image) }}" loading="lazy" alt=""
                         class="size-10 rounded-circle object-fit-cover">
                @else
                    <span class="avatar-title bg-success text-white fw-bold rounded-circle size-10 d-flex align-items-center justify-content-center fs-16">
                        {{ strtoupper(substr(Auth::user()->name ?? 'A', 0, 2)) }}
                    </span>
                @endif
                <div class="flex-grow-1 content overflow-hidden">
                    <h6 class="fw-medium text-truncate mb-0 text-white">{{ Auth::user()->name }}</h6>
                    <p class="fs-12 mb-0 text-white-50">
                        @if($agent)
                            Agent · {{ $agent->agent_level ?? 'Bronze' }}
                        @else
                            Agent
                        @endif
                    </p>
                </div>
                <div class="arrow">
                    <i data-lucide="chevron-down" class="size-4"></i>
                </div>
            </a>
            <div class="dropdown-menu p-4 profile-dropdown-menu">
                <div class="d-flex align-items-center gap-2">
                    <span class="avatar-title bg-success text-white fw-bold rounded-circle size-10 flex-shrink-0 d-flex align-items-center justify-content-center">
                        {{ strtoupper(substr(Auth::user()->name ?? 'A', 0, 2)) }}
                    </span>
                    <div class="flex-grow-1 overflow-hidden">
                        <h6 class="mb-0 text-truncate">{{ Auth::user()->name }}</h6>
                        <p class="mb-0 text-truncate fs-13 text-muted">{{ Auth::user()->email }}</p>
                    </div>
                </div>
                <div class="pt-2 mt-3 border-top">
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a class="profile-link" href="{{ route('agent.profile.view') }}">
                                <i data-lucide="user" class="d-inline-block me-2 size-4"></i> My Profile
                            </a>
                        </li>
                        <li>
                            <a class="profile-link" href="{{ route('agent.properties.houses.index') }}">
                                <i data-lucide="home" class="d-inline-block me-2 size-4"></i> My Listings
                            </a>
                        </li>
                        <li>
                            <form method="POST" action="{{ route('logout') }}" id="agent-logout-form">
                                @csrf
                                <a href="#" class="profile-link pb-0"
                                   onclick="event.preventDefault(); document.getElementById('agent-logout-form').submit();">
                                    <i data-lucide="log-out" class="d-inline-block me-2 size-4"></i> Log Out
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        {{-- Navigation --}}
        <div class="navbar-menu px-5" id="navbar-menu-list" data-simplebar>
            <ul class="list-unstyled p-0 navbar-nav-menu">

                {{-- OVERVIEW --}}
                <li class="nav-menu-title">Overview</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agent.dashboard.*') ? 'active' : '' }}"
                       href="{{ route('agent.dashboard.index') }}">
                        <span class="icons"><i class="las la-tachometer-alt"></i></span>
                        <span class="content">Dashboard</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agent.profile.*') ? 'active' : '' }}"
                       href="{{ route('agent.profile.view') }}">
                        <span class="icons"><i class="las la-id-card"></i></span>
                        <span class="content">My Profile</span>
                    </a>
                </li>

                {{-- MY PROPERTIES --}}
                <li class="nav-menu-title">My Properties</li>

                <li class="nav-item">
                    <a class="nav-link collapsed {{ request()->routeIs('agent.properties.*') || request()->routeIs('agent.designs.*') || request()->routeIs('agents.design-categories.*') ? 'active' : '' }}"
                       data-bs-toggle="collapse" href="#collapseAgentProperties">
                        <span class="icons"><i class="las la-home"></i></span>
                        <span class="content">Listings</span>
                        <span class="ms-auto menu-arrow"><i class="las la-angle-down"></i></span>
                    </a>
                    <div class="collapse {{ request()->routeIs('agent.properties.*') || request()->routeIs('agent.designs.*') || request()->routeIs('agents.design-categories.*') ? 'show' : '' }}"
                         id="collapseAgentProperties">
                        <ul class="nav-menu-sub">
                            <li>
                                <a href="{{ route('agent.properties.houses.index') }}"
                                   class="nav-link {{ request()->routeIs('agent.properties.houses.*') ? 'active' : '' }}">
                                    Houses
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('agent.properties.land.index') }}"
                                   class="nav-link {{ request()->routeIs('agent.properties.land*') ? 'active' : '' }}">
                                    Lands
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('agent.designs.index') }}"
                                   class="nav-link {{ request()->routeIs('agent.designs.*') ? 'active' : '' }}">
                                    Architectural Designs
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('agents.design-categories.index') }}"
                                   class="nav-link {{ request()->routeIs('agents.design-categories.*') ? 'active' : '' }}">
                                    Design Categories
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                {{-- BUSINESS --}}
                <li class="nav-menu-title">Business</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agents.tenders.*') ? 'active' : '' }}"
                       href="{{ route('agents.tenders.index') }}">
                        <span class="icons"><i class="las la-file-contract"></i></span>
                        <span class="content">Tenders</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agents.services.*') ? 'active' : '' }}"
                       href="{{ route('agents.services.index') }}">
                        <span class="icons"><i class="las la-concierge-bell"></i></span>
                        <span class="content">My Services</span>
                    </a>
                </li>

                {{-- CONTENT --}}
                <li class="nav-menu-title">Content</li>

                <li class="nav-item">
                    <a class="nav-link collapsed {{ request()->routeIs('agents.ads.*') || request()->routeIs('agents.announcements.*') ? 'active' : '' }}"
                       data-bs-toggle="collapse" href="#collapseAgentContent">
                        <span class="icons"><i class="las la-bullhorn"></i></span>
                        <span class="content">Promotions</span>
                        <span class="ms-auto menu-arrow"><i class="las la-angle-down"></i></span>
                    </a>
                    <div class="collapse {{ request()->routeIs('agents.ads.*') || request()->routeIs('agents.announcements.*') ? 'show' : '' }}"
                         id="collapseAgentContent">
                        <ul class="nav-menu-sub">
                            <li>
                                <a href="{{ route('agents.ads.index') }}"
                                   class="nav-link {{ request()->routeIs('agents.ads.*') ? 'active' : '' }}">
                                    Advertisements
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('agents.announcements.index') }}"
                                   class="nav-link {{ request()->routeIs('agents.announcements.*') ? 'active' : '' }}">
                                    Announcements
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                {{-- NETWORK --}}
                <li class="nav-menu-title">Network</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agents.consultants.*') ? 'active' : '' }}"
                       href="{{ route('agents.consultants.index') }}">
                        <span class="icons"><i class="las la-user-graduate"></i></span>
                        <span class="content">Consultants</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('agents.professionals.*') ? 'active' : '' }}"
                       href="{{ route('agents.professionals.index') }}">
                        <span class="icons"><i class="las la-hard-hat"></i></span>
                        <span class="content">Professionals</span>
                    </a>
                </li>

                {{-- QUICK ACTIONS --}}
                <li class="nav-menu-title">Quick Actions</li>

                <li class="nav-item">
                    <a class="nav-link" href="{{ route('agent.properties.houses.create') }}">
                        <span class="icons"><i class="las la-plus-circle"></i></span>
                        <span class="content">List a House</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="{{ route('agent.properties.lands.create') }}">
                        <span class="icons"><i class="las la-map-marked-alt"></i></span>
                        <span class="content">List a Land</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="{{ route('agent.designs.create') }}">
                        <span class="icons"><i class="las la-drafting-compass"></i></span>
                        <span class="content">Post a Design</span>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div>
<div id="sidebar-backdrop" class="sidebar-backdrop"></div>
