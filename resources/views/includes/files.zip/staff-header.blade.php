@php
/**
 * Staff Topbar Header
 * Notifications: pending approvals and recent content within the staff member's scope
 */

$pendingLands  = App\Models\Land::where('is_approved', false)->count();
$pendingHouses = App\Models\House::where('is_approved', false)->count();
$totalPending  = $pendingLands + $pendingHouses;

$recentAnnouncements = collect(App\Models\Announcement::latest()->take(5)->get()
    ->map(fn($a) => [
        'icon'       => 'las la-bullhorn',
        'color'      => 'info',
        'label'      => 'Announcement',
        'title'      => $a->title,
        'route'      => route('admin.announcements.show', $a->id),
        'created_at' => $a->created_at,
    ]));
@endphp

<header class="main-topbar gap-md-2" id="main-topbar">

    {{-- Brand / Toggle --}}
    <div class="navbar-brand">
        <div class="logos">
            <a href="{{ route('admin.dashboard') }}" aria-label="Logo">
                <img src="{{ asset('front/assets/img/logo/logo.png') }}" loading="lazy" height="18" alt="" class="logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo.png') }}" loading="lazy" height="18" alt="" class="logo-light">
            </a>
        </div>
        <button type="button" id="toggleSidebar" class="sidebar-toggle btn p-0" aria-label="sidebar-toggle">
            <i data-lucide="panel-right-open" class="size-4"></i>
        </button>
    </div>

    {{-- Search --}}
    <div class="align-items-center d-none d-lg-flex">
        <div class="position-relative navbar-search">
            <i data-lucide="search" class="size-4 icon"></i>
            <input type="search" class="form-control border-0 shadow-none" placeholder="Search…">
        </div>
    </div>

    {{-- Right Controls --}}
    <div class="d-flex align-items-center gap-2 gap-md-3 ms-auto">

        {{-- Pending Items --}}
        @if($totalPending > 0)
        <div class="dropdown d-none d-md-block">
            <button class="btn topbar-link position-relative" type="button"
                    aria-label="Pending Approvals" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="ri-time-line fs-lg"></i>
                <span class="notification-animate bg-warning rounded-circle"></span>
            </button>
            <div class="dropdown-menu dropdown-menu-end p-0" style="min-width:240px;">
                <div class="p-4 pb-2">
                    <h6 class="mb-0">Pending Review</h6>
                    <p class="text-muted fs-13 mb-0">{{ $totalPending }} items need attention</p>
                </div>
                <ul class="list-unstyled p-4 pt-2 vstack gap-3 mb-0">
                    @if($pendingLands > 0)
                    <li>
                        <a href="{{ route('admin.properties.lands.index') }}"
                           class="d-flex align-items-center gap-3 text-decoration-none text-body">
                            <span class="avatar-title bg-success-subtle text-success rounded-circle size-9 d-flex align-items-center justify-content-center">
                                <i class="las la-map-marked-alt fs-18"></i>
                            </span>
                            <div class="flex-grow-1">
                                <p class="mb-0 fw-medium fs-14">Land Listings</p>
                                <p class="mb-0 text-muted fs-12">{{ $pendingLands }} awaiting approval</p>
                            </div>
                            <span class="badge bg-warning">{{ $pendingLands }}</span>
                        </a>
                    </li>
                    @endif
                    @if($pendingHouses > 0)
                    <li>
                        <a href="{{ route('admin.properties.houses.index') }}"
                           class="d-flex align-items-center gap-3 text-decoration-none text-body">
                            <span class="avatar-title bg-primary-subtle text-primary rounded-circle size-9 d-flex align-items-center justify-content-center">
                                <i class="las la-home fs-18"></i>
                            </span>
                            <div class="flex-grow-1">
                                <p class="mb-0 fw-medium fs-14">House Listings</p>
                                <p class="mb-0 text-muted fs-12">{{ $pendingHouses }} awaiting approval</p>
                            </div>
                            <span class="badge bg-warning">{{ $pendingHouses }}</span>
                        </a>
                    </li>
                    @endif
                </ul>
            </div>
        </div>
        @endif

        {{-- Notifications --}}
        <div class="dropdown">
            <button class="btn topbar-link position-relative" type="button"
                    aria-label="Notifications" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="ri-notification-4-line fs-lg"></i>
                @if($recentAnnouncements->isNotEmpty())
                    <span class="notification-animate bg-info rounded-circle"></span>
                @endif
            </button>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-lg p-0">
                <div class="d-flex align-items-center gap-2 p-4 pb-0">
                    <h6 class="flex-grow-1 mb-0">Recent Announcements</h6>
                    <a href="{{ route('admin.announcements.index') }}" class="link link-custom-primary small">
                        View All <i class="ri-arrow-right-s-line"></i>
                    </a>
                </div>

                <div class="topbar-notifications p-4" style="max-height:300px; overflow-y:auto;">
                    <div class="vstack gap-4">
                        @forelse($recentAnnouncements as $notif)
                            <a href="{{ $notif['route'] }}" class="d-flex gap-3 py-1 rounded text-decoration-none">
                                <span class="avatar-title bg-{{ $notif['color'] }}-subtle text-{{ $notif['color'] }} rounded-circle size-9 flex-shrink-0 d-flex align-items-center justify-content-center">
                                    <i class="{{ $notif['icon'] }} fs-18"></i>
                                </span>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <span class="badge bg-{{ $notif['color'] }}-subtle text-{{ $notif['color'] }} fs-11 mb-1">
                                            {{ $notif['label'] }}
                                        </span>
                                        <span class="fs-12 text-muted ms-2 flex-shrink-0">
                                            {{ \Carbon\Carbon::parse($notif['created_at'])->diffForHumans() }}
                                        </span>
                                    </div>
                                    <p class="mb-0 fs-14 text-body fw-medium text-truncate" style="max-width:200px;">
                                        {{ $notif['title'] }}
                                    </p>
                                </div>
                            </a>
                        @empty
                            <div class="text-center py-4 text-muted">
                                <i class="las la-bell-slash fs-30 d-block mb-2"></i>
                                No recent announcements
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>

        {{-- Department Badge --}}
        <div class="d-none d-md-flex align-items-center">
            <span class="badge bg-info-subtle text-info fw-medium px-3 py-2">
                <i class="las la-building me-1"></i>
                {{ Auth::user()->staff?->department?->name ?? 'Staff' }}
            </span>
        </div>

        {{-- Dark Mode --}}
        <button type="button" id="darkModeButton" class="topbar-link topbar-mode btn" aria-label="Toggle theme">
            <i class="ri-moon-line fs-lg dark"></i>
            <i class="ri-sun-line fs-lg light"></i>
        </button>

        {{-- Staff Profile --}}
        <div class="dropdown profile-dropdown">
            <button class="btn px-0 d-flex align-items-center text-body dropdown-toggle" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                <span class="avatar-title bg-info text-white fw-bold rounded-circle p-1 size-9 d-flex align-items-center justify-content-center">
                    {{ strtoupper(substr(Auth::user()->name ?? 'S', 0, 2)) }}
                </span>
                <span class="text-start ms-3 d-none d-xl-block">
                    <span class="d-block fw-medium pr-name fs-sm">{{ Auth::user()->name }}</span>
                    <small class="text-muted pr-desc">
                        {{ Auth::user()->staff?->department?->name ?? 'Staff Member' }}
                    </small>
                </span>
            </button>
            <div class="dropdown-menu dropdown-menu-md p-4 profile-dropdown-menu">
                <ul class="list-unstyled mb-0">
                    <li>
                        <a class="profile-link" href="{{ route('activity-logs.index') }}">
                            <i class="ri-history-line d-inline-block me-2 fs-17"></i> Activity Logs
                        </a>
                    </li>
                    <li>
                        <a class="profile-link" href="{{ route('staff.departments.index') }}">
                            <i class="ri-building-line d-inline-block me-2 fs-17"></i> Departments
                        </a>
                    </li>
                    <li>
                        <a class="profile-link" href="{{ route('front.home') }}" target="_blank">
                            <i class="ri-external-link-line d-inline-block me-2 fs-17"></i> View Site
                        </a>
                    </li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}" id="topbar-staff-logout">
                            @csrf
                            <a href="#" class="profile-link pb-0"
                               onclick="event.preventDefault(); document.getElementById('topbar-staff-logout').submit();">
                                <i class="ri-logout-circle-r-line me-2 fs-17"></i> Log Out
                            </a>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
