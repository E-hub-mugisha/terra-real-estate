@php
/**
 * Agent Topbar Header
 * Notifications scoped to the authenticated agent's own listings
 */

$authAgent = Auth::user()->agent;
$agentId   = $authAgent?->id;

$myHouses = $agentId
    ? collect(App\Models\House::where('agent_id', $agentId)->latest()->take(5)->get()
        ->map(fn($h) => [
            'type'       => 'house',
            'icon'       => 'las la-home',
            'color'      => 'primary',
            'label'      => $h->is_approved ? 'House Approved' : 'House Pending',
            'badge_color'=> $h->is_approved ? 'success' : 'warning',
            'title'      => $h->title,
            'image'      => $h->image ?? null,
            'route'      => route('agent.properties.houses.show', $h->id),
            'created_at' => $h->created_at,
        ]))
    : collect();

$myLands = $agentId
    ? collect(App\Models\Land::where('agent_id', $agentId)->latest()->take(5)->get()
        ->map(fn($l) => [
            'type'       => 'land',
            'icon'       => 'las la-map-marked-alt',
            'color'      => 'success',
            'label'      => $l->is_approved ? 'Land Approved' : 'Land Pending',
            'badge_color'=> $l->is_approved ? 'success' : 'warning',
            'title'      => $l->title,
            'image'      => $l->image ?? null,
            'route'      => route('agent.properties.lands.show', $l->id),
            'created_at' => $l->created_at,
        ]))
    : collect();

$notifications = $myHouses
    ->merge($myLands)
    ->sortByDesc('created_at')
    ->take(8);

$pendingCount = $myHouses->where('badge_color', 'warning')->count()
              + $myLands->where('badge_color', 'warning')->count();
@endphp

<header class="main-topbar gap-md-2" id="main-topbar">

    {{-- Brand / Toggle --}}
    <div class="navbar-brand">
        <div class="logos">
            <a href="{{ route('agent.dashboard.index') }}" aria-label="Logo">
                <img src="{{ asset('front/assets/img/logo/logo.png') }}" loading="lazy" height="18" alt="" class="logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo.png') }}" loading="lazy" height="18" alt="" class="logo-light">
            </a>
        </div>
        <button type="button" id="toggleSidebar" class="sidebar-toggle btn p-0" aria-label="sidebar-toggle">
            <i data-lucide="panel-right-open" class="size-4"></i>
        </button>
    </div>

    {{-- Search --}}
    <div class="align-items-center d-none d-lg-flex">
        <div class="position-relative navbar-search">
            <i data-lucide="search" class="size-4 icon"></i>
            <input type="search" class="form-control border-0 shadow-none" placeholder="Search my listings…">
        </div>
    </div>

    {{-- Right Controls --}}
    <div class="d-flex align-items-center gap-2 gap-md-3 ms-auto">

        {{-- Quick Add --}}
        <div class="dropdown d-none d-md-block">
            <button class="btn topbar-link" type="button" aria-label="Quick Add" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="ri-add-circle-line fs-lg"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end p-0" style="min-width:200px;">
                <div class="p-3 pb-0">
                    <h6 class="mb-0 fs-14">Quick Add</h6>
                </div>
                <ul class="list-unstyled p-3 vstack gap-2 mb-0">
                    <li>
                        <a href="{{ route('agent.properties.houses.create') }}" class="d-flex align-items-center gap-2 text-decoration-none text-body py-1">
                            <i class="las la-home text-primary fs-18"></i>
                            <span class="fs-14">List a House</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('agent.properties.lands.create') }}" class="d-flex align-items-center gap-2 text-decoration-none text-body py-1">
                            <i class="las la-map-marked-alt text-success fs-18"></i>
                            <span class="fs-14">List a Land</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('agent.designs.create') }}" class="d-flex align-items-center gap-2 text-decoration-none text-body py-1">
                            <i class="las la-drafting-compass text-warning fs-18"></i>
                            <span class="fs-14">Post a Design</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('agents.tenders.create') }}" class="d-flex align-items-center gap-2 text-decoration-none text-body py-1">
                            <i class="las la-file-contract text-info fs-18"></i>
                            <span class="fs-14">Post a Tender</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        {{-- Notifications --}}
        <div class="dropdown">
            <button class="btn topbar-link position-relative" type="button"
                    aria-label="Notifications" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="ri-notification-4-line fs-lg"></i>
                @if($pendingCount > 0)
                    <span class="notification-animate bg-warning rounded-circle"></span>
                @endif
            </button>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-lg p-0">
                <div class="d-flex align-items-center gap-2 p-4 pb-0">
                    <h6 class="flex-grow-1 mb-0">My Listing Updates</h6>
                    @if($pendingCount > 0)
                        <span class="badge bg-warning-subtle text-warning">{{ $pendingCount }} Pending</span>
                    @endif
                </div>

                <div class="topbar-notifications p-4" style="max-height:320px; overflow-y:auto;">
                    <div class="vstack gap-4">
                        @forelse($notifications as $notif)
                            <a href="{{ $notif['route'] }}" class="d-flex gap-3 py-1 rounded text-decoration-none">
                                <div class="flex-shrink-0">
                                    @if($notif['image'])
                                        <img src="{{ asset('storage/' . $notif['image']) }}"
                                             alt="{{ $notif['title'] }}"
                                             class="rounded-circle size-9 object-fit-cover">
                                    @else
                                        <span class="avatar-title bg-{{ $notif['color'] }}-subtle text-{{ $notif['color'] }} rounded-circle size-9 d-flex align-items-center justify-content-center">
                                            <i class="{{ $notif['icon'] }} fs-18"></i>
                                        </span>
                                    @endif
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <span class="badge bg-{{ $notif['badge_color'] }}-subtle text-{{ $notif['badge_color'] }} fs-11 mb-1">
                                            {{ $notif['label'] }}
                                        </span>
                                        <span class="fs-12 text-muted ms-2 flex-shrink-0">
                                            {{ \Carbon\Carbon::parse($notif['created_at'])->diffForHumans() }}
                                        </span>
                                    </div>
                                    <p class="mb-0 fs-14 text-body fw-medium text-truncate" style="max-width:200px;">
                                        {{ $notif['title'] }}
                                    </p>
                                </div>
                            </a>
                        @empty
                            <div class="text-center py-4 text-muted">
                                <i class="las la-check-circle fs-30 d-block mb-2 text-success"></i>
                                All listings are up to date
                            </div>
                        @endforelse
                    </div>
                </div>

                <div class="border-top p-3 text-center">
                    <a href="{{ route('agent.properties.houses.index') }}" class="link link-custom-primary small">
                        View All Listings <i class="ri-arrow-right-s-line"></i>
                    </a>
                </div>
            </div>
        </div>

        {{-- Agent Level Badge --}}
        @if($authAgent)
        <div class="d-none d-md-flex align-items-center">
            @php
                $levelColors = ['Bronze' => 'warning', 'Silver' => 'secondary', 'Gold' => 'warning', 'Elite' => 'danger'];
                $levelColor  = $levelColors[$authAgent->agent_level ?? 'Bronze'] ?? 'warning';
            @endphp
            <span class="badge bg-{{ $levelColor }}-subtle text-{{ $levelColor }} fw-medium px-3 py-2">
                <i class="las la-trophy me-1"></i>
                {{ $authAgent->agent_level ?? 'Bronze' }}
            </span>
        </div>
        @endif

        {{-- Dark Mode --}}
        <button type="button" id="darkModeButton" class="topbar-link topbar-mode btn" aria-label="Toggle theme">
            <i class="ri-moon-line fs-lg dark"></i>
            <i class="ri-sun-line fs-lg light"></i>
        </button>

        {{-- Agent Profile --}}
        <div class="dropdown profile-dropdown">
            <button class="btn px-0 d-flex align-items-center text-body dropdown-toggle" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                @if($authAgent && $authAgent->profile_image)
                    <img src="{{ asset('storage/' . $authAgent->profile_image) }}"
                         loading="lazy" alt="{{ Auth::user()->name }}"
                         class="object-fit-cover rounded-circle size-9">
                @else
                    <span class="avatar-title bg-success text-white fw-bold rounded-circle p-1 size-9 d-flex align-items-center justify-content-center">
                        {{ strtoupper(substr(Auth::user()->name ?? 'A', 0, 2)) }}
                    </span>
                @endif
                <span class="text-start ms-3 d-none d-xl-block">
                    <span class="d-block fw-medium pr-name fs-sm">{{ Auth::user()->name }}</span>
                    <small class="text-muted pr-desc">Agent</small>
                </span>
            </button>
            <div class="dropdown-menu dropdown-menu-md p-4 profile-dropdown-menu">
                <ul class="list-unstyled mb-0">
                    <li>
                        <a class="profile-link" href="{{ route('agent.profile.view') }}">
                            <i class="ri-user-3-line d-inline-block me-2 fs-17"></i> My Profile
                        </a>
                    </li>
                    <li>
                        <a class="profile-link" href="{{ route('agent.properties.houses.index') }}">
                            <i class="ri-home-line d-inline-block me-2 fs-17"></i> My Listings
                        </a>
                    </li>
                    <li>
                        <a class="profile-link" href="{{ route('agents.services.index') }}">
                            <i class="ri-service-line d-inline-block me-2 fs-17"></i> My Services
                        </a>
                    </li>
                    <li>
                        <a class="profile-link" href="{{ route('front.home') }}" target="_blank">
                            <i class="ri-external-link-line d-inline-block me-2 fs-17"></i> View Site
                        </a>
                    </li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}" id="topbar-agent-logout">
                            @csrf
                            <a href="#" class="profile-link pb-0"
                               onclick="event.preventDefault(); document.getElementById('topbar-agent-logout').submit();">
                                <i class="ri-logout-circle-r-line me-2 fs-17"></i> Log Out
                            </a>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
