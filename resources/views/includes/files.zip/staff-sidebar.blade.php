<div id="main-sidebar" class="main-sidebar">
    <div class="sidebar-wrapper">

        {{-- Logo --}}
        <a href="{{ route('admin.dashboard') }}" class="navbar-brand">
            <div class="logo-lg">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="40" class="mx-auto logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="40" class="mx-auto logo-light">
            </div>
            <div class="logo-sm">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="50" class="mx-auto logo-dark">
                <img src="{{ asset('front/assets/img/logo/logo-white.png') }}" loading="lazy" aria-label="logo" alt="" height="50" class="mx-auto logo-light">
            </div>
        </a>

        {{-- Staff Profile --}}
        <div class="dropdown profile-dropdown">
            <a href="#!" class="btn d-flex align-items-center w-100 gap-2 p-4 text-start" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="avatar-title bg-info text-white fw-bold rounded-circle size-10 d-flex align-items-center justify-content-center fs-16">
                    {{ strtoupper(substr(Auth::user()->name ?? 'S', 0, 2)) }}
                </span>
                <div class="flex-grow-1 content overflow-hidden">
                    <h6 class="fw-medium text-truncate mb-0 text-white">{{ Auth::user()->name }}</h6>
                    <p class="fs-12 mb-0 text-white-50">
                        {{ Auth::user()->staff?->department?->name ?? 'Staff Member' }}
                    </p>
                </div>
                <div class="arrow">
                    <i data-lucide="chevron-down" class="size-4"></i>
                </div>
            </a>
            <div class="dropdown-menu p-4 profile-dropdown-menu">
                <div class="d-flex align-items-center gap-2">
                    <span class="avatar-title bg-info text-white fw-bold rounded-circle size-10 flex-shrink-0 d-flex align-items-center justify-content-center">
                        {{ strtoupper(substr(Auth::user()->name ?? 'S', 0, 2)) }}
                    </span>
                    <div class="flex-grow-1 overflow-hidden">
                        <h6 class="mb-0 text-truncate">{{ Auth::user()->name }}</h6>
                        <p class="mb-0 text-truncate fs-13 text-muted">{{ Auth::user()->email }}</p>
                    </div>
                </div>
                <div class="pt-2 mt-3 border-top">
                    <ul class="list-unstyled mb-0">
                        <li>
                            <form method="POST" action="{{ route('logout') }}" id="staff-logout-form">
                                @csrf
                                <a href="#" class="profile-link pb-0"
                                   onclick="event.preventDefault(); document.getElementById('staff-logout-form').submit();">
                                    <i data-lucide="log-out" class="d-inline-block me-2 size-4"></i> Log Out
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        {{-- Navigation --}}
        <div class="navbar-menu px-5" id="navbar-menu-list" data-simplebar>
            <ul class="list-unstyled p-0 navbar-nav-menu">

                {{-- OVERVIEW --}}
                <li class="nav-menu-title">Overview</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"
                       href="{{ route('admin.dashboard') }}">
                        <span class="icons"><i class="las la-tachometer-alt"></i></span>
                        <span class="content">Dashboard</span>
                    </a>
                </li>

                {{-- ORGANISATION --}}
                <li class="nav-menu-title">Organisation</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('staff.departments.*') ? 'active' : '' }}"
                       href="{{ route('staff.departments.index') }}">
                        <span class="icons"><i class="las la-building"></i></span>
                        <span class="content">Departments</span>
                    </a>
                </li>

                {{-- PROPERTIES (read-only / approval scope) --}}
                @canany(['approve-lands', 'approve-houses', 'view-properties'])
                <li class="nav-menu-title">Property Review</li>

                <li class="nav-item">
                    <a class="nav-link collapsed {{ request()->routeIs('admin.properties.*') ? 'active' : '' }}"
                       data-bs-toggle="collapse" href="#collapseStaffProperties">
                        <span class="icons"><i class="las la-home"></i></span>
                        <span class="content">Properties</span>
                        <span class="ms-auto menu-arrow"><i class="las la-angle-down"></i></span>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.properties.*') ? 'show' : '' }}"
                         id="collapseStaffProperties">
                        <ul class="nav-menu-sub">
                            <li>
                                <a href="{{ route('admin.properties.lands.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.properties.lands.*') ? 'active' : '' }}">
                                    Land Listings
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('admin.properties.houses.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.properties.houses.*') ? 'active' : '' }}">
                                    House Listings
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                @endcanany

                {{-- USER SUPPORT --}}
                @canany(['view-users', 'view-agents'])
                <li class="nav-menu-title">User Support</li>

                <li class="nav-item">
                    <a class="nav-link collapsed {{ request()->routeIs('admin.agents.*') || request()->routeIs('admin.users.*') ? 'active' : '' }}"
                       data-bs-toggle="collapse" href="#collapseStaffUsers">
                        <span class="icons"><i class="las la-users"></i></span>
                        <span class="content">Users & Agents</span>
                        <span class="ms-auto menu-arrow"><i class="las la-angle-down"></i></span>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.agents.*') || request()->routeIs('admin.users.*') ? 'show' : '' }}"
                         id="collapseStaffUsers">
                        <ul class="nav-menu-sub">
                            @can('view-agents')
                            <li>
                                <a href="{{ route('admin.agents.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.agents.*') ? 'active' : '' }}">
                                    Agents
                                </a>
                            </li>
                            @endcan
                            @can('view-users')
                            <li>
                                <a href="{{ route('admin.users.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
                                    General Users
                                </a>
                            </li>
                            @endcan
                        </ul>
                    </div>
                </li>
                @endcanany

                {{-- CONTENT MODERATION --}}
                @canany(['view-announcements', 'view-news'])
                <li class="nav-menu-title">Content Moderation</li>

                <li class="nav-item">
                    <a class="nav-link collapsed {{ request()->routeIs('admin.blogs.*') || request()->routeIs('admin.announcements.*') ? 'active' : '' }}"
                       data-bs-toggle="collapse" href="#collapseStaffContent">
                        <span class="icons"><i class="las la-newspaper"></i></span>
                        <span class="content">Content</span>
                        <span class="ms-auto menu-arrow"><i class="las la-angle-down"></i></span>
                    </a>
                    <div class="collapse {{ request()->routeIs('admin.blogs.*') || request()->routeIs('admin.announcements.*') ? 'show' : '' }}"
                         id="collapseStaffContent">
                        <ul class="nav-menu-sub">
                            @can('view-news')
                            <li>
                                <a href="{{ route('admin.blogs.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.blogs.*') ? 'active' : '' }}">
                                    News Articles
                                </a>
                            </li>
                            @endcan
                            @can('view-announcements')
                            <li>
                                <a href="{{ route('admin.announcements.index') }}"
                                   class="nav-link {{ request()->routeIs('admin.announcements.*') ? 'active' : '' }}">
                                    Announcements
                                </a>
                            </li>
                            @endcan
                        </ul>
                    </div>
                </li>
                @endcanany

                {{-- ACTIVITY --}}
                <li class="nav-menu-title">Monitoring</li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('activity-logs.*') ? 'active' : '' }}"
                       href="{{ route('activity-logs.index') }}">
                        <span class="icons"><i class="las la-history"></i></span>
                        <span class="content">Activity Logs</span>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</div>
<div id="sidebar-backdrop" class="sidebar-backdrop"></div>
